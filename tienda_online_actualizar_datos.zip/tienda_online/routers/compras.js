const express= require('express');
const ruta_compras= express.Router();
const conexion= require('../bd_mysql');


ruta_compras.get('/Listar_compras',(peticion,respuesta)=>{
  var sql=' select cli.cedula, cli.nombre,nombre_prod,cantidad_comp from cliente cli join compra on fk_cliente=cli.cedula join producto on fk_producto=id_producto';
    conexion.query(sql,(error,rows,fields)=>{
        if(!error){
            respuesta.render('compra',{comp:rows}); 
        }else{
            respuesta.send('error en la ejecucion de la consulta:'+error); 
        }
    });
});
module.exports= ruta_compras;
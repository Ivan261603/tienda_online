const express= require('express');
const ruta_producto= express.Router();
const conexion= require('../bd_mysql');


ruta_producto.get('/listar_productos',(peticion,respuesta)=>{
    var sql='select * from producto';
    conexion.query(sql,(error,rows,fields)=>{
        if(!error){
            respuesta.render('producto',{produ:rows}); 
        }else{
            respuesta.send('error en la ejecucion de la consulta:'+error); 
        }
    });
})    

 ruta_producto.get('/registrar',(peticion,respuesta)=>{
     respuesta.render('registrar_producto');
 });   


ruta_producto.post('/registrar_producto',(peticion,respuesta)=>{
    var id_producto=peticion.body.id_producto;
    var codigo_prod=peticion.body.codigo_prod;
    var nombre_prod=peticion.body.nombre_prod;
    var precio_prod=peticion.body.precio_prod;
    var stock=peticion.body.stock;
    var sql=`insert into producto(id_producto,codigo_prod,nombre_prod,precio_prod,stock)
    values(${id_producto},${codigo_prod},'${nombre_prod}',${precio_prod},${stock})`;

    conexion.query(sql,(error,rows,fields)=>{
        if(!error){
            respuesta.redirect('/producto/listar_productos');
        }
        else{console.log('error producto'+error);
    }
    });
});

ruta_producto.get('/eliminar/:id',(peticion,respuesta)=>{
    var cod_p=peticion.params.id;
    var sql=`delete from producto where id_producto=${cod_p};`
    conexion.query(sql,(error,rows,fields)=>{
        if(!error){
            respuesta.redirect('/producto/listar_productos');
        }
        else{
            console.log('error al listar'+error);
        }
    });
});

module.exports= ruta_producto;